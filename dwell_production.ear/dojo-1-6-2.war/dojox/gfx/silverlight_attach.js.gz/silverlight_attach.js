/*
	Copyright (c) 2004-2012, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


if(!dojo._hasResource["dojox.gfx.silverlight_attach"]){
dojo._hasResource["dojox.gfx.silverlight_attach"]=true;
dojo.provide("dojox.gfx.silverlight_attach");
dojo.require("dojox.gfx.silverlight");
dojo.experimental("dojox.gfx.silverlight_attach");
(function(){
var g=dojox.gfx,sl=g.silverlight;
sl.attachNode=function(_1){
return null;
};
sl.attachSurface=function(_2){
return null;
};
})();
}
