/*
	Copyright (c) 2004-2012, The Dojo Foundation All Rights Reserved.
	Available via Academic Free License >= 2.1 OR the modified BSD license.
	see: http://dojotoolkit.org/license for details
*/


define("dojo",["dojo/lib/kernel","dojo/_base/lang","dojo/_base/array","dojo/_base/declare","dojo/_base/connect","dojo/_base/Deferred","dojo/_base/json","dojo/_base/Color","dojo/_base/window","dojo/_base/event","dojo/_base/html","dojo/_base/NodeList","dojo/_base/query","dojo/_base/xhr","dojo/_base/fx"],function(_1){
return _1;
});
